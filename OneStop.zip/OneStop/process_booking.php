
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $service = $_POST['service'];
    $date = $_POST['date'];
    $time = $_POST['time'];

    // Simulate saving booking data (in a real app, use a database)
    $response = "Service: $service, Date: $date, Time: $time\n";
    file_put_contents('bookings.txt', $response, FILE_APPEND);

    echo "<h1>Thank you for booking with OneStop!</h1>";
    echo "<p>Service: $service</p>";
    echo "<p>Date: $date</p>";
    echo "<p>Time: $time</p>";
    echo "<a href='index.html'>Back to Home</a>";
}
?>
